#include "tests.h"
#include <iostream>

int main(int argc, char** argv) {
	RunTests();

	system("PAUSE");
	return 0;
}