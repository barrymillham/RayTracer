#ifndef TESTS_H
#define TESTS_H

void RunTests();

#endif