#ifndef __RAY_H
#define __RAY_H


class Ray {
public:
	Ray(){}

private:

};

#endif